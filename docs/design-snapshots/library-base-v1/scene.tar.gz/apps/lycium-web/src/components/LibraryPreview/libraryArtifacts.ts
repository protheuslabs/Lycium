import * as THREE from "three";
import type { LibraryMaterials } from "./libraryMaterials";
import { LIBRARY } from "./libraryOrbit";

function box(group: THREE.Group, material: THREE.Material, size: [number, number, number], position: [number, number, number]) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  group.add(mesh);
  return mesh;
}

function cylinder(group: THREE.Group, material: THREE.Material, radius: number, height: number, position: [number, number, number]) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, height, 16), material);
  mesh.position.set(...position);
  group.add(mesh);
  return mesh;
}

function rollingLadder(materials: LibraryMaterials) {
  const group = new THREE.Group();
  const height = 4.5;
  const lean = 0.72;
  const angle = Math.atan2(lean, height);
  for (const x of [-0.34, 0.34]) {
    const rail = box(group, materials.wood, [0.075, Math.hypot(height, lean), 0.1], [x, height / 2 + 0.12, lean / 2]);
    rail.rotation.x = angle;
    const wheel = cylinder(group, materials.black, 0.095, 0.06, [x, 0.1, 0]);
    wheel.rotation.z = Math.PI / 2;
    const bracket = cylinder(group, materials.brass, 0.065, 0.05, [x, height + 0.08, lean + 0.03]);
    bracket.rotation.z = Math.PI / 2;
  }
  for (let rung = 1; rung <= 13; rung += 1) {
    const y = rung / 14 * height;
    box(group, materials.wood, [0.69, 0.065, 0.1], [0, y + 0.12, y / height * lean]);
  }
  return group;
}

function scrolls(materials: LibraryMaterials) {
  const group = new THREE.Group();
  for (let row = 0; row < 3; row += 1) {
    for (let index = 0; index < 5 - row; index += 1) {
      const x = (index - (4 - row) / 2) * 0.22;
      const roll = cylinder(group, materials.paper, 0.095, 0.5, [x, 0.11 + row * 0.19, 0]);
      roll.rotation.x = Math.PI / 2;
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.071, 0.009, 5, 20), materials.wood);
      rim.position.set(x, 0.11 + row * 0.19, -0.255);
      group.add(rim);
    }
  }
  return group;
}

function globe(materials: LibraryMaterials) {
  const group = new THREE.Group();
  cylinder(group, materials.brass, 0.24, 0.04, [0, 0.03, 0]);
  cylinder(group, materials.brass, 0.035, 0.25, [0, 0.14, 0]);
  const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.26, 24, 16), materials.teal);
  sphere.position.y = 0.46;
  group.add(sphere);
  for (const tilt of [0, Math.PI / 2, Math.PI / 4]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.012, 5, 40), materials.brass);
    ring.position.y = 0.46;
    ring.rotation.set(Math.PI / 2, tilt, 0.25);
    group.add(ring);
  }
  return group;
}

function laptop(materials: LibraryMaterials, vintage: boolean) {
  const group = new THREE.Group();
  const shell = vintage ? materials.marble : materials.black;
  box(group, shell, [0.95, 0.05, 0.52], [0, 0.04, -0.05]);
  box(group, shell, [0.9, 0.58, vintage ? 0.4 : 0.045], [0, 0.35, 0.13]);
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.77, 0.45), materials.screen);
  screen.rotation.y = Math.PI;
  screen.position.set(0, 0.36, vintage ? -0.075 : 0.103);
  group.add(screen);
  for (let row = 0; row < 3; row += 1) {
    for (let key = 0; key < 10; key += 1) {
      box(group, vintage ? materials.wood : materials.marble, [0.055, 0.012, 0.045], [(key - 4.5) * 0.075, 0.075, -0.2 + row * 0.06]);
    }
  }
  return group;
}

function camera(materials: LibraryMaterials) {
  const group = new THREE.Group();
  box(group, materials.black, [0.8, 0.42, 0.3], [0, 0.23, 0]);
  box(group, materials.brass, [0.8, 0.05, 0.32], [0, 0.44, 0]);
  box(group, materials.black, [0.25, 0.14, 0.22], [0, 0.5, 0]);
  const lens = cylinder(group, materials.brass, 0.19, 0.2, [0, 0.23, -0.23]);
  lens.rotation.x = Math.PI / 2;
  const glass = cylinder(group, materials.teal, 0.155, 0.012, [0, 0.23, -0.34]);
  glass.rotation.x = Math.PI / 2;
  return group;
}

function bust(materials: LibraryMaterials) {
  const group = new THREE.Group();
  box(group, materials.marble, [0.55, 0.08, 0.38], [0, 0.04, 0]);
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.29, 20, 12), materials.marble);
  torso.scale.set(1, 0.6, 0.65);
  torso.position.y = 0.23;
  group.add(torso);
  cylinder(group, materials.marble, 0.09, 0.16, [0, 0.43, 0]);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 20, 16), materials.marble);
  head.scale.set(0.85, 1.2, 0.9);
  head.position.y = 0.64;
  group.add(head);
  box(group, materials.marble, [0.055, 0.075, 0.07], [0, 0.64, -0.14]);
  return group;
}

function clock(materials: LibraryMaterials) {
  const group = new THREE.Group();
  box(group, materials.wood, [0.5, 0.68, 0.24], [0, 0.36, 0]);
  const face = cylinder(group, materials.paper, 0.2, 0.025, [0, 0.43, -0.14]);
  face.rotation.x = Math.PI / 2;
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.21, 0.018, 6, 32), materials.brass);
  rim.position.set(0, 0.43, -0.16);
  group.add(rim);
  box(group, materials.black, [0.015, 0.13, 0.01], [0, 0.49, -0.16]);
  const hand = box(group, materials.black, [0.12, 0.015, 0.01], [0.055, 0.43, -0.17]);
  hand.rotation.z = -0.2;
  return group;
}

function readingTable(materials: LibraryMaterials) {
  const group = new THREE.Group();
  box(group, materials.wood, [3.2, 0.14, 1.3], [0, 0.85, 0]);
  for (const x of [-1.35, 1.35]) for (const z of [-0.48, 0.48]) {
    box(group, materials.wood, [0.1, 0.8, 0.1], [x, 0.4, z]);
  }
  for (const z of [-1.1, 1.1]) {
    box(group, materials.wood, [0.48, 0.07, 0.48], [0, 0.45, z]);
    box(group, materials.wood, [0.48, 0.55, 0.07], [0, 0.75, z + Math.sign(z) * 0.2]);
    for (const x of [-0.18, 0.18]) for (const offset of [-0.18, 0.18]) {
      box(group, materials.wood, [0.05, 0.43, 0.05], [x, 0.22, z + offset]);
    }
  }
  for (const x of [-0.22, 0.22]) {
    const page = box(group, materials.paper, [0.42, 0.035, 0.55], [x, 0.95, 0]);
    page.rotation.z = Math.sign(x) * 0.08;
  }
  cylinder(group, materials.brass, 0.1, 0.03, [1, 0.95, 0]);
  cylinder(group, materials.brass, 0.015, 0.4, [1, 1.15, 0]);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.18, 16, 1, true), materials.teal);
  shade.position.set(1, 1.38, 0);
  group.add(shade);
  return group;
}

export function addLibraryArtifacts(scene: THREE.Scene, materials: LibraryMaterials) {
  const makers = [scrolls, globe, camera, bust, clock, (m: LibraryMaterials) => laptop(m, true), (m: LibraryMaterials) => laptop(m, false)];
  for (let level = 0; level < LIBRARY.levels; level += 1) {
    for (let bay = 0; bay < LIBRARY.bays; bay += 1) {
      const angle = (bay + 0.5) / LIBRARY.bays * Math.PI * 2;
      if (bay % 3 === 1) {
        const artifact = makers[(Math.floor(bay / 3) + level * 3) % makers.length](materials);
        const radius = LIBRARY.wallRadius - 0.85;
        artifact.position.set(Math.sin(angle) * radius, level * LIBRARY.levelHeight + 2.08, Math.cos(angle) * radius);
        artifact.rotation.y = angle;
        scene.add(artifact);
        if (level === 0 || level === 2) {
          const rolls = scrolls(materials);
          rolls.position.set(Math.sin(angle) * radius, level * LIBRARY.levelHeight + 1.2, Math.cos(angle) * radius);
          rolls.rotation.y = angle;
          scene.add(rolls);
        }
      }
      if (bay % 4 === 0) {
        const ladder = rollingLadder(materials);
        const radius = LIBRARY.wallRadius - 1.65;
        ladder.position.set(Math.sin(angle) * radius, level * LIBRARY.levelHeight + (level ? 0.18 : 0), Math.cos(angle) * radius);
        ladder.rotation.y = angle;
        scene.add(ladder);
        if (level === 0) {
          const table = readingTable(materials);
          const tableRadius = LIBRARY.wallRadius - 8;
          table.position.set(Math.sin(angle) * tableRadius, 0, Math.cos(angle) * tableRadius);
          table.rotation.y = angle;
          scene.add(table);
        }
      }
    }
  }
}
